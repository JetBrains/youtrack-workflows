/*
NB: README.md in workflow packages will be supported soon.

* Notifies users when they are set as issue verifiers.
* Requires setting 'Verified in build' value when changing state to 'Verified',
  and sets current user as 'Verified by' field value.
* Requires adding a comment when changing state to 'Without verification'
*/