/*
NB: README.md in workflow packages will be supported soon.

* When a comment from an external user is required,
  internal user sets issue State to 'Wait for Reply' manually.
* When a comment is added, issue is automatically reopened.
* Assignee gets a notification if no comments are added within 5 days.
*/