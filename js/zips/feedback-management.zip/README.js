/*
NB: README.md in workflow packages will be supported soon.

Handle feedback.
*/