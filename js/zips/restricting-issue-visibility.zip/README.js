/*
NB: README.md in worklflow packages will be supported soon.

This workflow contains the rules for the 'Restricting Issue Visibility' use-case,
described in detail in this blog post:
https://blog.jetbrains.com/youtrack/2017/11/make-it-workflow-part-1-restricting-issue-visibility/
 */