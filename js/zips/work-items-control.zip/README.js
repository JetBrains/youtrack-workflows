/*
NB: README.md in workflow packages will be supported soon.

This workflow contains the rules for the 'Tracking Spent Time' use-case,
described in detail in this blog post:
https://blog.jetbrains.com/youtrack/2018/03/make-it-workflow-part-6-tracking-spent-time/
*/