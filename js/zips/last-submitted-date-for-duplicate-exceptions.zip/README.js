/*
NB: README.md in workflow packages will be supported soon.

Update the last submitted date for the main issue
when a new 'is duplicated by' link is added to it.*/