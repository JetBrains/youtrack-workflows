/*
NB: README.md in workflow packages will be supported soon.

Open issue as soon as it becomes assigned.
*/