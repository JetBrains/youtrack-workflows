/*
NB: README.md in worklflow packages will be supported soon.

This workflow contains the rules for the 'Streamlining Issue Reporting' use-case,
described in detail in this blog post:
https://blog.jetbrains.com/youtrack/2017/11/make-it-workflow-part-3-streamlining-issue-reporting/
 */