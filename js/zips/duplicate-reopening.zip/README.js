/*
NB: README.md in workflow packages will be supported soon.

Reopen an issue if all duplicate links are removed.
*/