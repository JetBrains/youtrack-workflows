/*
NB: README.md in workflow packages will be supported soon.

'Fixed in build' field management.
*/