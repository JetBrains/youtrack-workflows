/*
NB: README.md in workflow packages will be supported soon.

This workflow contains the rules for the 'Mastering Mailbox Integrations' use-case,
described in detail in this blog post:
https://blog.jetbrains.com/youtrack/2018/08/make-it-workflow-part-10-mastering-mailbox-integrations/
*/