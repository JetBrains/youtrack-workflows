/*
NB: README.md in workflow packages will be supported soon.

This workflow contains the rules for the 'Generating New Issues' use-case,
described in detail in this blog post:
http://blog.jetbrains.com/youtrack/2017/12/make-it-workflow-part-4-generating-new-issues/
 */