/*
NB: README.md in workflow packages will be supported soon.

This workflow contains the rules for the 'Generating Time Reports' use-case,
described in detail in this blog post:
https://blog.jetbrains.com/youtrack/2018/03/make-it-workflow-part-7-generating-time-reports/
*/