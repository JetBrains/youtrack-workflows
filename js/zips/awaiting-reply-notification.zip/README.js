/*
NB: README.md in workflow packages will be supported soon.

If an issue has a recent non-developer comment, send a notification
to a specific user (support team member). This check is performed
at a given time (daily at 12 pm by default).
*/