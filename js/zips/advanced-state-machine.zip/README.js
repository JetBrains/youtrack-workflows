/*
NB: README.md in workflow packages will be supported soon.

Advanced State Machine.
*/