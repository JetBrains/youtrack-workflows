/*
NB: README.md in workflow packages will be supported soon.

Prohibit duplicating issues with different visibility groups.
*/