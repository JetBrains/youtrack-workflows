/*
NB: README.md in worklflow packages will be supported soon.

This workflow contains the rules for the 'Preventing Unwanted Updates' use-case,
described in detail in this blog post:
http://blog.jetbrains.com/youtrack/2017/11/make-it-workflow-part-2-preventing-unwanted-updates/
 */