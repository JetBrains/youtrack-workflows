/*
NB: README.md in workflow packages will be supported soon.

This workflow sums subtasks estimations (integer) and
saves the result to parent issue. It supports multilevel
parent-subtasks trees.
*/