/*
NB: README.md in workflow packages will be supported soon.

Provide an ability to have the issue unblocked (denoted with a
"is blocked by" - "blocks" relationship) when the blocker is resolved.
*/