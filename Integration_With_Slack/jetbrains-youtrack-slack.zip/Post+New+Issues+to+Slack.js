statelessrule("Post New Issues to Slack", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "becomesReported", []);
}, function(ctx) {
  var issueLink = "<" + invoke(ctx, ctx.issue, "getUrl", []) + "|" + invoke(ctx, ctx.issue, "getId", []) + ">";
  var message = "Issue created: ";
  var sanitizedSummary = strOp("replace", safeCall(ctx.issue,"get", ["summary"], null), "\"", "\\\"");
  
  var palette = strOp("splitByWholeSeparator", "#FFFFFF,#8d5100,#ce6700,#409600,#0070e4,#900052,#0050a1,#2f9890,#8e1600,#dc0083,#7dbd36,#ff7123,#ff7bc3,#fed74a,#b7e281,#d8f7f3,#e6e6e6,#e6f6cf,#ffee9c,#ffc8ea,#e30000,#e0f1fb,#fce5f1,#f7e9c1,#92e1d5,#a6e0fc,#e0c378,#bababa,#25beb2,#42a3df,#878787,#4d4d4d,#246512,#00665e,#553000,#1a1a1a", ",");
  var color = palette.get(safeCall(safeCall(ctx.issue,"get", ["Priority"]),"get", ["colorIndex"], 0));
  
  if (!color) {
    color = "#edb431";
  }
  
  // Add the following to create a caption for the message
  // \"title\":\"Your caption goes here\"
  var payload = "{\"attachments\":[{\"fallback\":\"" + message + issueLink + "\",\"pretext\":\"" + message + issueLink + "\",\"color\":\"" + color + "\",\"fields\":[{\"value\":\"" + sanitizedSummary + "\",\"short\":false}]}]}";
  
  invoke(ctx, ctx.issue, "doHttpPost", ["https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",payload]);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "summary", type: {name: "string", primitive: true}}, {name: "Priority", type: {name: "EnumField", fields: [{name: "colorIndex", type: {name: "int", primitive: true}}]}}]}]));