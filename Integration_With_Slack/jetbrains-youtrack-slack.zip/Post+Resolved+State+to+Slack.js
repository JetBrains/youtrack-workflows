statelessrule("Post Resolved State to Slack", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "becomesResolved", []);
}, function(ctx) {
  var json = "{\"text\":\"" + safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["name"], null) + ": <" + invoke(ctx, ctx.issue, "getUrl", []) + "|" + invoke(ctx, ctx.issue, "getId", []) + "> " + safeCall(ctx.issue,"get", ["summary"], null) + " by " + safeCall(ctx.loggedInUser,"get", ["fullName"], null) + "\"}";
  invoke(ctx, ctx.issue, "addHttpHeader", ["Content-Type","application/x-www-form-urlencoded"]);
  invoke(ctx, ctx.issue, "addHttpFormField", ["payload",json]);
  
  var response = invoke(ctx, ctx.issue, "doHttpPost", ["https://hooks.slack.com/services/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",json]);
  if ((strOp("contains", response, "201"))) {
    log("debug", response, ctx);
  } else {
    log("error", response, ctx);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "summary", type: {name: "string", primitive: true}}, {name: "State", type: {name: "State", fields: [{name: "name", type: {name: "string", primitive: true}}]}}]}, {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}]}]));