statemachine("States", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User"}}, {name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}], methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}]}}, {name: "summary", type: {name: "string", primitive: true}}, {name: "State", type: {name: "State", values: ["Submitted", "Open", "Reopened", "Obsolete", "Duplicate", "In Progress", "To be discussed", "Can't Reproduce", "As designed", "Won't fix", "Invalid", "Incomplete", "Fixed", "W/O verification", "Verified", "Wait for Reply"]}}, {name: "Verified by", type: {name: "User"}}, {name: "Verified in build", type: {name: "Build"}}]}]));
from("Submitted").after(joda.Period.days(3)).when(function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["State"]), find("Submitted"));
}).perform(function(ctx) {
  var user = safeCall(ctx.issue,"get", ["Assignee"]);
  
  if (equals(user, null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  
  invoke(ctx, user, "notify", ["[Youtrack, State reminder] Issue " + invoke(ctx, ctx.issue, "getId", []) + " is still Submitted: " + safeCall(ctx.issue,"get", ["summary"], null),"Hi, " + safeCall(user,"get", ["fullName"], null) + "! <br><br> Issue <a href=\"" + invoke(ctx, ctx.issue, "getUrl", []) + "\">" + invoke(ctx, ctx.issue, "getId", []) + "</a>" + " is still in Submitted state:" + " <a href=\"" + invoke(ctx, ctx.issue, "getUrl", []) + "\">" + safeCall(ctx.issue,"get", ["summary"], null) + "</a>" + "<br> Please start working on it or specify other accurate state.<br><br>" + "<p style=\"color: gray;font-size: 12px;margin-top: 1em;border-top: 1px solid #D4D5D6\">" + "Sincerely yours, YouTrack" + "</p>"]);
}).loop();
from("Submitted").on("fix").transitTo("Fixed");
from("Submitted").on("open").transitTo("Open");
from("Submitted").on("in progress").transitTo("In Progress");
from("Submitted").on("discuss").transitTo("To be discussed");
from("Submitted").on("can't reproduce").transitTo("Can't Reproduce");
from("Submitted").on("obsolete").transitTo("Obsolete");
from("Submitted").on("duplicate").transitTo("Duplicate");
from("Submitted").on("as designed").transitTo("As designed");
from("Submitted").on("invalidate").transitTo("Invalid");
from("Open").on("in progress").transitTo("In Progress");
from("Open").on("discuss").transitTo("To be discussed");
from("Open").on("fix").transitTo("Fixed");
from("Open").on("obsolete").transitTo("Obsolete");
from("Open").on("duplicate").transitTo("Duplicate");
from("Open").on("can't reproduce").transitTo("Can't Reproduce");
from("Open").on("as designed").transitTo("As designed");
from("Open").on("invalid").transitTo("Invalid");
from("Open").on("wait").transitTo("Wait for Reply");
from("Reopened").on("open").transitTo("Open");
from("Obsolete").on("reopen").transitTo("Open");
from("Duplicate").on("reopen").transitTo("Open");
from("In Progress").on("reopen").transitTo("Open");
from("In Progress").on("fix").transitTo("Fixed");
from("In Progress").on("can't reproduce").transitTo("Can't Reproduce");
from("In Progress").on("obsolete").transitTo("Obsolete");
from("In Progress").on("as designed").transitTo("As designed");
from("To be discussed").on("in progress").transitTo("In Progress");
from("To be discussed").on("duplicate").transitTo("Duplicate");
from("To be discussed").on("obsolete").transitTo("Obsolete");
from("Can't Reproduce").on("reopen").transitTo("Open");
from("As designed").on("reopen").transitTo("Open");
from("Won't fix").on("reopen").transitTo("Open");
from("Invalid").on("reopen").transitTo("Open");
from("Incomplete").on("reopen").transitTo("Open");
from("Fixed").on("reopen").transitTo("Open");
from("Fixed").on("verify").transitTo("Verified");
from("Fixed").on("can't verify").transitTo("W/O verification");
from("W/O verification").onEnter(function(ctx) {
  safeCall(ctx.issue,"set", ["Verified by", ctx.loggedInUser], null);
});
from("W/O verification").on("reopen").transitTo("Open");
from("Verified").on("reopen").transitTo("Open");
from("Verified").onEnter(function(ctx) {
  require(ctx, ctx.issue, "Verified in build", "Specify verified in build");
  safeCall(ctx.issue,"set", ["Verified by", ctx.loggedInUser], null);
});
from("Verified").onExit(function(ctx) {
  safeCall(ctx.issue,"set", ["Verified in build", null], null);
});
from("Wait for Reply").on("fix").transitTo("Fixed");
from("Wait for Reply").on("open").transitTo("Open");
from("Wait for Reply").on("in progress").transitTo("In Progress");
from("Wait for Reply").on("discuss").transitTo("To be discussed");
from("Wait for Reply").on("can't reproduce").transitTo("Can't Reproduce");
from("Wait for Reply").on("obsolete").transitTo("Obsolete");
from("Wait for Reply").on("duplicate").transitTo("Duplicate");
from("Wait for Reply").on("as designed").transitTo("As designed");
from("Wait for Reply").on("invalidate").transitTo("Invalid");