statelessrule("Assert Fix version is set for Fixed issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Fixed")], false);
}, function(ctx) {
  require(ctx, ctx.issue, "Fix versions", "Please set the 'Fix versions' field!");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Fix versions", type: {name: "ProjectVersion", multiple: true}}, {name: "State", type: {name: "State", values: ["Fixed"]}}]}]));