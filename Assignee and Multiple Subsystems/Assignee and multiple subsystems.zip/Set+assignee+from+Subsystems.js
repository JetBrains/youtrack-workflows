statelessrule("Set assignee from Subsystems", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["Subsystems"], false);
}, function(ctx) {
  var owner = null;
  for(var subsystem_iterator = safeCall(ctx.issue,"get", ["Subsystems"]).iterator(); subsystem_iterator.hasNext();) {
    var subsystem = subsystem_iterator.next();
    if (equals(owner, null)) {
      owner = safeCall(subsystem,"get", ["owner"]);
    } else if (!equals(safeCall(subsystem,"get", ["owner"]), owner)) {
      owner = null;
      break;
    }
  }
  if (!equals(owner, null) && equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
    safeCall(ctx.issue,"set", ["Assignee", owner], null);
  }
  
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Subsystems", type: {name: "OwnedField", multiple: true, fields: [{name: "owner", type: {name: "User"}}]}}, {name: "Assignee", type: {name: "User"}}]}]));