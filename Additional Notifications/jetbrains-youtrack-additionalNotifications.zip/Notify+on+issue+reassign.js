statelessrule("Notify on issue reassign", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "isReported", []) && safeCall(ctx.issue,"isChanged", ["Assignee"], false);
}, function(ctx) {
  var oldAssignee = safeCall(ctx.issue,"getOldValue", ["Assignee"]);
  var newAssignee;
  if (equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
    newAssignee = "nobody";
  } else {
    newAssignee = safeCall(safeCall(ctx.issue,"get", ["Assignee"]),"get", ["login"], null);
  }
  if (!equals(oldAssignee, null)) {
    invoke(ctx, oldAssignee, "notify", ["[YouTrack, Reassigned] Issue " + invoke(ctx, ctx.issue, "getId", []) + ": " + safeCall(ctx.issue,"get", ["summary"], null),"Issue " + "<a href=\"" + invoke(ctx, ctx.issue, "getUrl", []) + "\">" + invoke(ctx, ctx.issue, "getId", []) + "</a> was reassigned from you to " + newAssignee]);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User", fields: [{name: "login", type: {name: "string", primitive: true}}], methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}, {name: "summary", type: {name: "string", primitive: true}}]}]));