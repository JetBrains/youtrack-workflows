statelessrule("No Comments for Verified Issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["State"]), find("Verified")) && !safeCall(ctx.issue,"becomes", ["State", find("Verified")], false);
}, function(ctx) {
  assert(ctx, safeCall(safeCall(ctx.issue,"added", ["comments"]),"isEmpty", [], false),"Commenting for fixed and verified issues is disabled.");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Verified"]}}, {name: "comments", type: {name: "IssueComment", multiple: true}}]}]));