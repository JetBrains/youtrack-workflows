statelessrule("Set tag waiting for reply (answered)", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["comments"]),"isNotEmpty", [], false);
}, function(ctx) {
  if (!invoke(ctx, safeCall(safeCall(safeCall(ctx.issue,"added", ["comments"]),"last", []),"get", ["author"]), "isInGroup", ["developer"])) {
    invoke(ctx, ctx.issue, "removeTag", ["waiting for reply"]);
    invoke(ctx, ctx.issue, "addTag", ["waiting for reply(answered?)"]);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "comments", type: {name: "IssueComment", multiple: true, fields: [{name: "author", type: {name: "User", methods: [{name: "isInGroup", returnType: {name: "boolean"}, paramTypes: [{name: "string"}]}]}}]}}]}]));