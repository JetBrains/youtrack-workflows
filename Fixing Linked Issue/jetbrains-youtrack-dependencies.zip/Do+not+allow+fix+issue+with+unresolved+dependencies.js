statelessrule("Do not allow fix issue with unresolved dependencies", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Fixed")], false) && safeCall(safeCall(ctx.issue,"get", ["depends on"]),"isNotEmpty", [], false);
}, function(ctx) {
  for(var dep_iterator = safeCall(ctx.issue,"get", ["depends on"]).iterator(); dep_iterator.hasNext();) {
    var dep = dep_iterator.next();
    assert(ctx, safeCall(safeCall(dep,"get", ["State"]),"get", ["isResolved"], false),"The issue has unresolved dependencies and thus cannot be set Fixed!");
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}], values: ["Fixed"]}}, {name: "Depend", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is required for", type: {name: "Issue", multiple: true}}, {name: "depends on", type: {name: "Issue", multiple: true}}]}}]}]));