statelessrule("Description template for external users", model.Event.BEFORE_FLUSH, function(ctx) {
  return !invoke(ctx, ctx.issue, "isReported", []) && equals(safeCall(ctx.issue,"get", ["description"], null), null);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["description", "What steps will reproduce the problem?\n" + "1.\n2.\n3.\n\n" + "What is the expected result?\n\n" + "What happens instead?\n\n" + "Please provide any additional information below.\n" + "Attach a screenshot if possible\n"], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "description", type: {name: "string", primitive: true}}]}]));