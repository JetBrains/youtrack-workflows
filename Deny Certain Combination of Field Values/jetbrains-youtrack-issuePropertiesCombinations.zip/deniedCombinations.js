statelessrule("deniedCombinations", model.Event.BEFORE_FLUSH, function(ctx) {
  return true;
}, function(ctx) {
  assert(ctx, !(equals(safeCall(ctx.issue,"get", ["Priority"]), find("Show-stopper")) && equals(safeCall(ctx.issue,"get", ["State"]), find("Submitted"))),"Denied fields combination detected (Submitted Show-stopper)");
  
  assert(ctx, !(equals(safeCall(ctx.issue,"get", ["State"]), find("Open")) && equals(safeCall(ctx.issue,"get", ["Assignee"]), null)),"Denied fields combination detected (Open Unassigned)");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Submitted", "Open"]}}, {name: "Priority", type: {name: "EnumField", values: ["Show-stopper"]}}, {name: "Assignee", type: {name: "User"}}]}]));