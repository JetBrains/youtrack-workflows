statelessrule("deniedCombinations", model.Event.BEFORE_FLUSH, function(ctx) {
  return true;
}, function(ctx) {
  assert(ctx, !(equals(safeCall(ctx.issue,"get", ["Priority"]), find("Show-stopper")) && equals(safeCall(ctx.issue,"get", ["State"]), find("Submitted"))),localize("deniedCombinations.Denied_fields_combination_detected_Submitted_Show-stopper"));
  
  assert(ctx, !(equals(safeCall(ctx.issue,"get", ["State"]), find("Open")) && equals(safeCall(ctx.issue,"get", ["Assignee"]), null)),localize("deniedCombinations.Denied_fields_combination_detected_Open_Unassigned"));
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Submitted", "Open"]}}, {name: "Priority", type: {name: "EnumField", values: ["Show-stopper"]}}, {name: "Assignee", type: {name: "User"}}]}]));