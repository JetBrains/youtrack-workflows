onschedulestatelessrule("send notification to a user mentioned in comment", model.Event.CRON, "0 0 12 * * ?", null, function(ctx) {
  var mentionedUser;
  for(var comment_iterator = safeCall(ctx.issue,"get", ["comments"]).iterator(); comment_iterator.hasNext();) {
    var comment = comment_iterator.next();
    if (strOp("contains", safeCall(comment,"get", ["text"], null), "remind @") && datePlusPeriod(safeCall(comment,"get", ["created"], 0), joda.Period.days(1)) > now()) {
      mentionedUser = strOp("substringBetween", safeCall(comment,"get", ["text"], null), "remind @", " ");
    }
  }
  
  for(var user_iterator = invoke(ctx, find("New Users", classType(ctx, "UserGroup", false)), "getUsers", []).iterator(); user_iterator.hasNext();) {
    var user = user_iterator.next();
    if (strOp("equals", safeCall(user,"get", ["login"], null), mentionedUser)) {
      invoke(ctx, user, "notify", ["Reminder","You are reminded because of comment in " + invoke(ctx, ctx.issue, "getId", [])]);
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "comments", type: {name: "IssueComment", multiple: true, fields: [{name: "text", type: {name: "string", primitive: true}}, {name: "created", type: {name: "instant", primitive: true}}]}}]}, {name: "User", fields: [{name: "login", type: {name: "string", primitive: true}}]}, {name: "UserGroup", values: ["New Users"]}]));