statelessrule("User can't remove all duplicate links from issue in state Duplicate", model.Event.BEFORE_FLUSH, function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["State"]), find("Duplicate")) && safeCall(safeCall(ctx.issue,"removed", ["duplicates"]),"isNotEmpty", [], false);
}, function(ctx) {
  if (safeCall(safeCall(ctx.issue,"get", ["duplicates"]),"isEmpty", [], false)) {
    safeCall(ctx.issue,"set", ["State", find("Open")], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}, {name: "State", type: {name: "State", values: ["Open", "Duplicate"]}}]}]));