statelessrule("When have duplicate link set issue state to Duplicate", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["duplicates"]),"isNotEmpty", [], false) && !equals(safeCall(ctx.issue,"get", ["State"]), find("Duplicate"));
}, function(ctx) {
  if (safeCall(ctx.issue,"canBeWrittenBy", ["State", ctx.loggedInUser], false)) {
    safeCall(ctx.issue,"set", ["State", find("Duplicate")], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Duplicate"]}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}]}]));