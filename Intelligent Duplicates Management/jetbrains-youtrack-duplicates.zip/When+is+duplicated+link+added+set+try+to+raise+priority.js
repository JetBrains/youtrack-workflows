statelessrule("When is duplicated link added set try to raise priority", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["is duplicated by"]),"isNotEmpty", [], false);
}, function(ctx) {
  var priorityOrdinal = safeCall(safeCall(ctx.issue,"get", ["Priority"]),"get", ["ordinal"], 0);
  for(var source_iterator = safeCall(ctx.issue,"added", ["is duplicated by"]).iterator(); source_iterator.hasNext();) {
    var source = source_iterator.next();
    var sourcePriority = safeCall(source,"get", ["Priority"]);
    var sourcePriorityOrdinal = safeCall(sourcePriority,"get", ["ordinal"], 0);
    if (priorityOrdinal > sourcePriorityOrdinal) {
      priorityOrdinal = sourcePriorityOrdinal;
      safeCall(ctx.issue,"set", ["Priority", sourcePriority], null);
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Priority", type: {name: "EnumField", fields: [{name: "ordinal", type: {name: "int", primitive: true}}]}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}]}]));