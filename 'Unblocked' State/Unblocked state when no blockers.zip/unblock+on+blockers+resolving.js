statelessrule("unblock on blockers resolving", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["isResolved"], false) && !safeCall(safeCall(ctx.issue,"getOldValue", ["State"]),"get", ["isResolved"], false);
}, function(ctx) {
  for(var dependant_iterator = safeCall(ctx.issue,"get", ["blocks"]).iterator(); dependant_iterator.hasNext();) {
    var dependant = dependant_iterator.next();
    if (equals(safeCall(safeCall(dependant,"get", ["is blocked by"]),"first", []), safeCall(safeCall(dependant,"get", ["is blocked by"]),"last", []))) {
      // e.g. it's source issue
      safeCall(dependant,"set", ["State", find("Unblocked")], null);
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}], values: ["Unblocked"]}}, {name: "Blocker", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "blocks", type: {name: "Issue", multiple: true}}, {name: "is blocked by", type: {name: "Issue", multiple: true}}]}}]}]));