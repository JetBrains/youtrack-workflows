onschedulestatelessrule("ColorOnDeadlineApproachMorning", model.Event.CRON, "0 0 9 * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.not(w.link("State").link("isResolved"));
}, function(ctx) {
  if (safeCall(ctx.issue,"get", ["Due Date"], 0) >= datePlusPeriod(now(), joda.Period.days(8))) {
    safeCall(ctx.issue,"set", ["DeadlineApproach", find("More than a week")], null);
  }
  if (datePlusPeriod(now(), joda.Period.days(7)) > safeCall(ctx.issue,"get", ["Due Date"], 0)) {
    safeCall(ctx.issue,"set", ["DeadlineApproach", find("1 week")], null);
  }
  if (datePlusPeriod(now(), joda.Period.days(5)) > safeCall(ctx.issue,"get", ["Due Date"], 0)) {
    safeCall(ctx.issue,"set", ["DeadlineApproach", find("4-6 days")], null);
  }
  if (datePlusPeriod(now(), joda.Period.days(3)) > safeCall(ctx.issue,"get", ["Due Date"], 0)) {
    safeCall(ctx.issue,"set", ["DeadlineApproach", find("2-3 days")], null);
  }
  if (datePlusPeriod(now(), joda.Period.days(2)) > safeCall(ctx.issue,"get", ["Due Date"], 0)) {
    safeCall(ctx.issue,"set", ["DeadlineApproach", find("1 day")], null);
  }
  
}).addRequirements(requirements([{name: "Issue", fields: [{name: "DeadlineApproach", type: {name: "EnumField", values: ["More than a week", "1 week", "4-6 days", "2-3 days", "1 day"]}}, {name: "Due Date", type: {name: "instant", primitive: true}}, {name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}]}}]}]));