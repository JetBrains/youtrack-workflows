statelessrule("Assert Assignee not null", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["Assignee"], false);
}, function(ctx) {
  assert(ctx, !equals(safeCall(ctx.issue,"get", ["Assignee"]), null),"Assignee can't be null!");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User"}}]}]));