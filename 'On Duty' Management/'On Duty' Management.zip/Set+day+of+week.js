onschedulestatelessrule("Set day of week", model.Event.CRON, "0 0 0 * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.eq("State",find("On duty"));
}, function(ctx) {
  safeCall(ctx.issue,"set", ["Day of week", (safeCall(ctx.issue,"get", ["Day of week"], 0) + 1) % 7], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Day of week", type: {name: "int", primitive: true}}, {name: "State", type: {name: "State", values: ["On duty"]}}]}]));