onschedulestatelessrule("Set Today's Duty Based on is required for", model.Event.CRON, "0 0 10 * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.and(w.eq("State",find("On duty")),w.and(w.neq("Day of week",5),w.neq("Day of week",6)));
}, function(ctx) {
  if (datePlusPeriod(safeCall(ctx.issue,"get", ["updated"], 0), joda.Period.seconds(10)) < now()) {
    // set new duty
    var nextDuty;
    nextDuty = safeCall(safeCall(ctx.issue,"get", ["is required for"]),"first", []);
    var stop = 0;
    
    if (equals(nextDuty, null) || equals(safeCall(nextDuty,"get", ["Assignee"]), null)) {
      invoke(ctx, safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]), "notify", ["Duty","Duties chain should be provided by 'is required for' link and 'Duty' store field must be non-empty.",true]);
    }
    
    while(!equals(stop, -1) && stop < 50) {
      if (equals(safeCall(nextDuty,"get", ["State"]), find("Active"))) {
        safeCall(nextDuty,"set", ["Day of week", safeCall(ctx.issue,"get", ["Day of week"], 0)], null);
        safeCall(nextDuty,"set", ["State", find("On duty")], null);
        
        invoke(ctx, safeCall(ctx.issue,"get", ["Assignee"]), "notify", ["Duty: You are no longer on duty",safeCall(safeCall(ctx.issue,"get", ["Assignee"]),"get", ["fullName"], null) + ", " + " you just came off duty.<br><br>The new man-on-duty is " + safeCall(safeCall(nextDuty,"get", ["Assignee"]),"get", ["fullName"], null) + ".",true]);
        
        safeCall(ctx.issue,"set", ["State", find("Active")], null);
        log("debug", "Duty changed to: " + safeCall(safeCall(nextDuty,"get", ["Assignee"]),"get", ["fullName"], null), ctx);
        
        stop = -1;
      } else if (equals(safeCall(nextDuty,"get", ["State"]), find("On a rest"))) {
        nextDuty = safeCall(safeCall(nextDuty,"get", ["is required for"]),"first", []);
        stop = stop + 1;
        
      } else {
        invoke(ctx, safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]), "notify", ["Duty","States should be only 'Active' or 'On a rest'",true]);
        
        stop = -1;
      }
    }
    
    invoke(ctx, safeCall(nextDuty,"get", ["Assignee"]), "notify", ["Duty: You are on duty",safeCall(safeCall(nextDuty,"get", ["Assignee"]),"get", ["fullName"], null) + ", " + "you are on duty today.<br><br> Don't forget to handle " + "<a href=\"http://youtrack.jetbrains.net/issues/JT?q=%23Unassigned+%23Unresolved+created%3A+Yesterday%2C+Today+sort+by%3A+Priority+\">" + "new issues in Youtrack." + "</a>" + "<br>" + "<p style=\"color: gray;font-size: 12px;margin-top: 1em;border-top: 1px solid #D4D5D6\">" + "Sincerely yours, YouTrack" + "</p>",true]);
    
    var curIssue;
    curIssue = nextDuty;
    var preventInfinite = 0;
    while(!equals(curIssue, ctx.issue) && preventInfinite < 50) {
      if (equals(safeCall(curIssue,"get", ["State"]), find("Active"))) {
        assert(ctx, !equals(safeCall(curIssue,"get", ["Assignee"]), null),"Assignee must me not null!");
        
        invoke(ctx, safeCall(curIssue,"get", ["Assignee"]), "notify", ["Duty: Man-on-duty was changed","Today's man-on-duty is " + safeCall(safeCall(nextDuty,"get", ["Assignee"]),"get", ["fullName"], null) + ".",true]);
      }
      curIssue = safeCall(safeCall(curIssue,"get", ["is required for"]),"first", []);
      preventInfinite = preventInfinite + 1;
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["On duty", "Active", "On a rest"]}}, {name: "Day of week", type: {name: "int", primitive: true}}, {name: "Depend", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is required for", type: {name: "Issue", multiple: true}}, {name: "depends on", type: {name: "Issue", multiple: true}}]}}, {name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}, {name: "boolean"}]}]}}]}}, {name: "Assignee", type: {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}], methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}, {name: "boolean"}]}]}}, {name: "updated", type: {name: "instant", primitive: true}}]}]));