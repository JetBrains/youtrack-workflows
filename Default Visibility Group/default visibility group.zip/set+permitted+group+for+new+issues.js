statelessrule("set permitted group for new issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return !invoke(ctx, ctx.issue, "isReported", []) && invoke(ctx, safeCall(ctx.issue,"get", ["reporter"]), "isInGroup", ["Reporters"]);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["permittedGroup", find("Developers")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "permittedGroup", type: {name: "UserGroup", values: ["Developers"]}}, {name: "reporter", type: {name: "User", methods: [{name: "isInGroup", returnType: {name: "boolean"}, paramTypes: [{name: "string"}]}]}}]}]));