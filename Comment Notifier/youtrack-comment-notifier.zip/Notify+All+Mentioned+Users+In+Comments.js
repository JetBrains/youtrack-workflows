statelessrule("Notify All Mentioned Users In Comments", model.Event.BEFORE_FLUSH, function(ctx) {
  return strOp("containsIgnoreCase", safeCall(safeCall(safeCall(ctx.issue,"added", ["comments"]),"last", []),"get", ["text"], null), "@");
}, function(ctx) {
  var mentionedUsers = strOp("splitByWholeSeparator", safeCall(safeCall(safeCall(ctx.issue,"get", ["comments"]),"last", []),"get", ["text"], null), "@");
  for(var mentionedUser_iterator = mentionedUsers.iterator(); mentionedUser_iterator.hasNext();) {
    var mentionedUser = mentionedUser_iterator.next();
    var mentionedUserEndIndex = strOp("indexOf", mentionedUser, " ");
    var mentionedUserName = strOp("substring", mentionedUser, 0, mentionedUserEndIndex);
    for(var user_iterator = invoke(ctx, find("All Users", classType(ctx, "UserGroup", false)), "getUsers", []).iterator(); user_iterator.hasNext();) {
      var user = user_iterator.next();
      if (strOp("equals", safeCall(user,"get", ["login"], null), mentionedUserName)) {
        invoke(ctx, user, "notify", ["You were mentioned in a comment on " + safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["name"], null),"Your name was mentioned in comment " + invoke(ctx, ctx.issue, "getId", []) + "<br/><br/>\"" + safeCall(safeCall(safeCall(ctx.issue,"get", ["comments"]),"last", []),"get", ["text"], null) + "\" - " + safeCall(safeCall(safeCall(safeCall(ctx.issue,"get", ["comments"]),"last", []),"get", ["author"]),"get", ["fullName"], null)]);
      }
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "comments", type: {name: "IssueComment", multiple: true, fields: [{name: "text", type: {name: "string", primitive: true}}, {name: "author", type: {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}]}}]}}, {name: "project", type: {name: "Project", fields: [{name: "name", type: {name: "string", primitive: true}}]}}]}, {name: "User", fields: [{name: "login", type: {name: "string", primitive: true}}]}, {name: "UserGroup", values: ["All Users"]}]));