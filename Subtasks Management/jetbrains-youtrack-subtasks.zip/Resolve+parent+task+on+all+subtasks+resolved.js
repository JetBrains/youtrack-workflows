statelessrule("Resolve parent task on all subtasks resolved", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["isResolved"], false) && (equals(safeCall(ctx.issue,"getOldValue", ["State"]), null) || !safeCall(safeCall(ctx.issue,"getOldValue", ["State"]),"get", ["isResolved"], false)) && safeCall(safeCall(ctx.issue,"get", ["subtask of"]),"isNotEmpty", [], false);
}, function(ctx) {
  for(var parent_iterator = safeCall(ctx.issue,"get", ["subtask of"]).iterator(); parent_iterator.hasNext();) {
    var parent = parent_iterator.next();
    if (!invoke(ctx, parent, "isResolved", [])) {
      var allSubtasksResolved = true;
      for(var subtask_iterator = safeCall(parent,"get", ["parent for"]).iterator(); subtask_iterator.hasNext();) {
        var subtask = subtask_iterator.next();
        if (!(invoke(ctx, subtask, "isResolved", []))) {
          allSubtasksResolved = false;
          break;
        }
      }
      if (allSubtasksResolved) {
        safeCall(parent,"set", ["State", find("Fixed")], null);
        message(ctx,"Automatically fix " + safeCall(parent,"get", ["Type"]) + " " + invoke(ctx, parent, "getId", []));
      }
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Subtask", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "parent for", type: {name: "Issue", multiple: true, methods: [{name: "isResolved", returnType: {name: "boolean"}}]}}, {name: "subtask of", type: {name: "Issue", multiple: true, methods: [{name: "getId", returnType: {name: "string"}}, {name: "isResolved", returnType: {name: "boolean"}}]}}]}}, {name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}], values: ["Fixed"]}}, {name: "Type", type: {name: "EnumField"}}]}]));