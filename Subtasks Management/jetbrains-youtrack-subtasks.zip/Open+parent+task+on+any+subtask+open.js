statelessrule("Open parent task on any subtask open", model.Event.BEFORE_FLUSH, function(ctx) {
  return !safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["isResolved"], false) && (!equals(safeCall(ctx.issue,"getOldValue", ["State"]), null) && safeCall(safeCall(ctx.issue,"getOldValue", ["State"]),"get", ["isResolved"], false)) && safeCall(safeCall(ctx.issue,"get", ["subtask of"]),"isNotEmpty", [], false);
}, function(ctx) {
  for(var parent_iterator = safeCall(ctx.issue,"get", ["subtask of"]).iterator(); parent_iterator.hasNext();) {
    var parent = parent_iterator.next();
    if (invoke(ctx, parent, "isResolved", [])) {
      safeCall(parent,"set", ["State", find("Open")], null);
      message(ctx,"Automatically reopen " + safeCall(parent,"get", ["Type"]) + " " + invoke(ctx, parent, "getId", []));
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}], values: ["Open"]}}, {name: "Type", type: {name: "EnumField"}}, {name: "Subtask", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "parent for", type: {name: "Issue", multiple: true}}, {name: "subtask of", type: {name: "Issue", multiple: true, methods: [{name: "getId", returnType: {name: "string"}}, {name: "isResolved", returnType: {name: "boolean"}}]}}]}}]}]));