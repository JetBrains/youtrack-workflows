statelessrule("Open parent task on any subtask open", model.Event.BEFORE_FLUSH, function(ctx) {
  return !equals(safeCall(ctx.issue,"get", ["State"]), null) && !safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["isResolved"], false) && (!equals(safeCall(ctx.issue,"getOldValue", ["State"]), null) && safeCall(safeCall(ctx.issue,"getOldValue", ["State"]),"get", ["isResolved"], false)) && safeCall(safeCall(ctx.issue,"get", ["subtask of"]),"isNotEmpty", [], false);
}, function(ctx) {
  var parent = safeCall(safeCall(ctx.issue,"get", ["subtask of"]),"first", []);
  if (invoke(ctx, parent, "isResolved", [])) {
    safeCall(parent,"set", ["State", find("Open")], null);
    
    if (!equals(safeCall(parent,"get", ["Type"]), null)) {
      message(ctx,localize("Open_parent_task_on_any_subtask_open.Automatically_reopen_{0}_{1}", safeCall(parent,"get", ["Type"]), invoke(ctx, parent, "getId", [])));
    } else {
      message(ctx,localize("Open_parent_task_on_any_subtask_open.Automatically_reopen_{0}", invoke(ctx, parent, "getId", [])));
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Subtask", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "parent for", type: {name: "Issue", multiple: true}}, {name: "subtask of", type: {name: "Issue", multiple: true, methods: [{name: "getId", returnType: {name: "string"}}, {name: "isResolved", returnType: {name: "boolean"}}]}}]}}, {name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}], values: ["Open"]}}, {name: "Type", type: {name: "EnumField"}}]}]));