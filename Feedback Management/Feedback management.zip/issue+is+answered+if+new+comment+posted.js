statelessrule("issue is answered if new comment posted", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["comments"]),"isNotEmpty", [], false);
}, function(ctx) {
  if (invoke(ctx, safeCall(safeCall(safeCall(ctx.issue,"get", ["comments"]),"last", []),"get", ["author"]), "isInGroup", ["youtrack-developers"])) {
    safeCall(ctx.issue,"set", ["State", find("Answered")], null);
  } else {
    safeCall(ctx.issue,"set", ["State", find("Unanswered")], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Answered", "Unanswered"]}}, {name: "comments", type: {name: "IssueComment", multiple: true, fields: [{name: "author", type: {name: "User", methods: [{name: "isInGroup", returnType: {name: "boolean"}, paramTypes: [{name: "string"}]}]}}]}}]}]));