statelessrule("resolve on mark as SPAM", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["Type", find("Spam")], false);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["State", find("Answered")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Answered"]}}, {name: "Type", type: {name: "EnumField", values: ["Spam"]}}]}]));