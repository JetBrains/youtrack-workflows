onschedulestatelessrule("notify about unanswered feedback", model.Event.CRON, "0 0 11 * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.and(w.eq("State",find("Unanswered")),w.neq("Type",find("Spam")));
}, function(ctx) {
  var user = safeCall(ctx.issue,"get", ["Assignee"]);
  if (equals(user, null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  
  invoke(ctx, user, "notify", ["There's unanswered feedback [" + invoke(ctx, ctx.issue, "getId", []) + "]","There's unanswered feedback <a href='" + invoke(ctx, ctx.issue, "getUrl", []) + "'>" + invoke(ctx, ctx.issue, "getId", []) + "</a>"]);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User"}}, {name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}]}}, {name: "Type", type: {name: "EnumField", values: ["Spam"]}}, {name: "State", type: {name: "State", values: ["Unanswered"]}}]}]));