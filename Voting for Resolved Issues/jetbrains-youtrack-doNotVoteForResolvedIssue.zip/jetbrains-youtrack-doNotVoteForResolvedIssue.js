statelessrule("jetbrains-youtrack-doNotVoteForResolvedIssue", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "isResolved", []);
}, function(ctx) {
  assert(ctx, !safeCall(ctx.issue,"isChanged", ["votes"], false),"Voting for a resolved issue is not allowed.");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "votes", type: {name: "int", primitive: true}}]}]));