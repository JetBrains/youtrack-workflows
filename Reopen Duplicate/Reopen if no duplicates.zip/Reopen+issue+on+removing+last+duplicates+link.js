statelessrule("Reopen issue on removing last duplicates link", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["duplicates"], false) && safeCall(safeCall(ctx.issue,"get", ["duplicates"]),"isEmpty", [], false);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["State", find("Open")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Open"]}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}]}]));