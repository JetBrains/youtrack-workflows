onschedulestatelessrule("Notify assignee about overdue issues", model.Event.CRON, "0 0 10 * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.and(w.eq("resolved",null),w.plt("Due Date",now()));
}, function(ctx) {
  var user;
  if (equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  } else {
    user = safeCall(ctx.issue,"get", ["Assignee"]);
  }
  invoke(ctx, user, "notify", ["Issue is overdue","Please, look at the issue: " + invoke(ctx, ctx.issue, "getId", [])]);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User"}}]}}, {name: "Assignee", type: {name: "User"}}, {name: "resolved", type: {name: "instant", primitive: true}}, {name: "Due Date", type: {name: "instant", primitive: true}}]}]));