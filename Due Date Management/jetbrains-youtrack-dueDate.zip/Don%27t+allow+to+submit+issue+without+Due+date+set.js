statelessrule("Don't allow to submit issue without Due date set", model.Event.BEFORE_FLUSH, function(ctx) {
  return !invoke(ctx, ctx.issue, "isReported", []);
}, function(ctx) {
  require(ctx, ctx.issue, "Due Date", "You must set the Due date!");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Due Date", type: {name: "instant", primitive: true}}]}]));