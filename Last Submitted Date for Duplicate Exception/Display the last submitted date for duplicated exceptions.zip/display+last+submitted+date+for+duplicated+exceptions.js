statelessrule("display last submitted date for duplicated exceptions", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["is duplicated by"]),"isNotEmpty", [], false);
}, function(ctx) {
  var lastDuplicate = safeCall(ctx.issue,"get", ["Last duplicate"], 0);
  for(var source_iterator = safeCall(ctx.issue,"added", ["is duplicated by"]).iterator(); source_iterator.hasNext();) {
    var source = source_iterator.next();
    var addedDuplicate = safeCall(source,"get", ["created"], 0);
    if (lastDuplicate < addedDuplicate) {
      lastDuplicate = addedDuplicate;
      safeCall(ctx.issue,"set", ["Last duplicate", lastDuplicate], null);
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Last duplicate", type: {name: "instant", primitive: true}}, {name: "created", type: {name: "instant", primitive: true}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}]}]));