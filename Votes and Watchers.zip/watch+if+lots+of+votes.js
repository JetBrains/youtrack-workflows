statelessrule("watch if lots of votes", model.Event.BEFORE_FLUSH, function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["votes"], 0), 10);
}, function(ctx) {
  invoke(ctx, safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]), "watchIssue", [ctx.issue]);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User", methods: [{name: "watchIssue", returnType: {name: "void"}, paramTypes: [{name: "Issue"}]}]}}]}}, {name: "votes", type: {name: "int", primitive: true}}]}]));