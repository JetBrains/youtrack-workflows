statelessrule("Post Comment to Slack", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["comments"]),"isNotEmpty", [], false);
}, function(ctx) {
  var text = "";
  for(var comment_iterator = safeCall(ctx.issue,"added", ["comments"]).iterator(); comment_iterator.hasNext();) {
    var comment = comment_iterator.next();
    text = text + safeCall(safeCall(comment,"get", ["author"]),"get", ["fullName"], null) + ": \\\"" + strOp("replace", safeCall(comment,"get", ["text"], null), "\"", "\\\"") + "\\\"\\n";
  }
  
  var issue_details = "<" + invoke(ctx, ctx.issue, "getUrl", []) + "|" + invoke(ctx, ctx.issue, "getId", []) + "> [" + safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["name"], null) + "] " + safeCall(ctx.issue,"get", ["summary"], null) + " by " + safeCall(safeCall(ctx.issue,"get", ["reporter"]),"get", ["fullName"], null);
  
  var json = "{\"text\":\"" + text + "\\nOn " + issue_details + "\"}";
  
  invoke(ctx, ctx.issue, "addHttpHeader", ["Content-Type","application/x-www-form-urlencoded"]);
  invoke(ctx, ctx.issue, "addHttpFormField", ["payload",json]);
  
  var response = invoke(ctx, ctx.issue, "doHttpPost", ["https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",issue_details]);
  if ((strOp("contains", response, "201"))) {
    log("debug", response, ctx);
  } else {
    log("error", response, ctx);
    log("error", "payload was: " + json, ctx);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "comments", type: {name: "IssueComment", multiple: true, fields: [{name: "text", type: {name: "string", primitive: true}}, {name: "author", type: {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}]}}]}}, {name: "reporter", type: {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}]}}, {name: "summary", type: {name: "string", primitive: true}}, {name: "State", type: {name: "State", fields: [{name: "name", type: {name: "string", primitive: true}}]}}]}]));