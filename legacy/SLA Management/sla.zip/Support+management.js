statemachine("Support management", "Support state").addRequirements(requirements([{name: "Issue", fields: [{name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}, {name: "watchIssue", returnType: {name: "void"}, paramTypes: [{name: "Issue"}]}]}}]}}, {name: "Support state", type: {name: "State", values: ["Open", "Approved", "Reproduced", "Visit on-site", "Closed"]}}]}, {name: "UserGroup", values: ["sales"]}]));
from("Open").after(joda.Period.hours(1)).perform(function(ctx) {
  invoke(ctx, safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]), "notify", ["[YouTrack, Approvement]","Issue " + invoke(ctx, ctx.issue, "getId", []) + " hasn't been approved within 1 hour."]);
}).loop();
from("Open").on("approve").transitTo("Approved");
from("Approved").after(joda.Period.days(1)).perform(function(ctx) {
  invoke(ctx, safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]), "notify", ["[YouTrack, Reproduction]","Issue " + invoke(ctx, ctx.issue, "getId", []) + " hasn't been reproduced within a day."]);
  invoke(ctx, safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]), "watchIssue", [ctx.issue]);
  
  invoke(ctx, find("sales", classType(ctx, "UserGroup", false)), "notifyAllUsers", ["[YouTrack, Reproduced]","Issue " + invoke(ctx, ctx.issue, "getId", []) + " hasn't been reproduced within a day."]);
}).loop();
from("Approved").on("reproduce").transitTo("Reproduced");
from("Reproduced").after(joda.Period.days(3)).perform(function(ctx) {
  invoke(ctx, find("sales", classType(ctx, "UserGroup", false)), "notifyAllUsers", ["[YouTrack, Visit on-site]","Issue " + invoke(ctx, ctx.issue, "getId", []) + " needs your attention.."]);
  
}).loop();
from("Reproduced").on("visit").transitTo("Visit on-site");
from("Reproduced").on("close").transitTo("Closed");
from("Visit on-site").on("close").transitTo("Closed");
from("Closed").on("reopen").transitTo("Open");