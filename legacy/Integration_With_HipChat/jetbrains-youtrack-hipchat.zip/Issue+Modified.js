statelessrule("Issue Modified", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "isReported", []) && !invoke(ctx, ctx.issue, "becomesReported", []);
}, function(ctx) {
  
  // Set card caption
  var title = "Youtrack issue modified:" + invoke(ctx, ctx.issue, "getId", []);
  
  // Generate brief card description in html format
  var description = "<a href=\"" + invoke(ctx, ctx.issue, "getUrl", []) + "\"><strong>" + invoke(ctx, ctx.issue, "getId", []) + "</strong></a>: " + strOp("abbreviate", safeCall(ctx.issue,"get", ["summary"], null), 100);
  
  // Escape special characters
  description = strOp("replace", strOp("replace", strOp("replace", strOp("replaceChars", description, "\n\r\t", ""), "\\", "\\\\"), "\"", "\\\""), "&", "&amp;");
  
  // Generate unique card id
  var id = safeCall(ctx.issue,"get", ["updated"], 0) + "";
  
  // Set Youtrack logo for our Card
  var logo = "https://confluence.jetbrains.com/download/attachments/37235566/YTHB?version=2&modificationDate=1450796776000&api=v2";
  
  // Generate card attributes for some of changed fields
  var attributes = "[";
  
  // Add attribute if issue State has changed
  if (safeCall(ctx.issue,"isChanged", ["State"], false)) {
    var change = safeCall(ctx.issue,"getOldValue", ["State"]) + " → " + safeCall(ctx.issue,"get", ["State"]);
    var stateChangeAttr = "{\"label\": \"State\", \"value\": {\"label\":\"" + change + "\", \"style\":\"lozenge-current\"}}";
    attributes = attributes + stateChangeAttr;
  }
  
  // Add attribute if issue Type has changed
  if (safeCall(ctx.issue,"isChanged", ["Type"], false)) {
    var change = safeCall(ctx.issue,"getOldValue", ["Type"]) + " → " + safeCall(ctx.issue,"get", ["Type"]);
    var typeChangeAttr = "{\"label\": \"Type\", \"value\": {\"label\":\"" + change + "\", \"style\":\"lozenge-current\"}}";
    
    // separate JSON array entries with ','
    if (!equals(attributes, "[")) {
      attributes = attributes + ", ";
    }
    attributes = attributes + typeChangeAttr;
  }
  
  // Add attribute if issue Priority has changed
  if (safeCall(ctx.issue,"isChanged", ["Priority"], false)) {
    var change = safeCall(ctx.issue,"getOldValue", ["Priority"]) + " → " + safeCall(ctx.issue,"get", ["Priority"]);
    var priorityChangeAttr = "{\"label\": \"Priority\", \"value\": {\"label\":\"" + change + "\", \"style\":\"lozenge-current\"}}";
    
    // separate JSON array entries with ','
    if (!equals(attributes, "[")) {
      attributes = attributes + ", ";
    }
    attributes = attributes + priorityChangeAttr;
  }
  
  // Add attribute if issue Assignee has changed
  if (safeCall(ctx.issue,"isChanged", ["Assignee"], false)) {
    
    // set name of old assignee
    var oldAssignee = "";
    if (!equals(safeCall(ctx.issue,"getOldValue", ["Assignee"]), null)) {
      oldAssignee = safeCall(safeCall(ctx.issue,"getOldValue", ["Assignee"]),"get", ["fullName"], null) + "";
    } else {
      oldAssignee = "unassigned";
    }
    
    // set name of new assignee
    var newAssignee = "";
    if (!equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
      newAssignee = safeCall(safeCall(ctx.issue,"get", ["Assignee"]),"get", ["fullName"], null) + "";
    } else {
      newAssignee = "unassigned";
    }
    
    
    var change = oldAssignee + " → " + newAssignee;
    var assigneeChangeAttr = "{\"label\": \"Assignee\", \"value\": {\"label\":\"" + change + "\", \"style\":\"lozenge-current\"}}}";
    
    // separate JSON array entries with ','
    if (!equals(attributes, "[")) {
      attributes = attributes + ", ";
    }
    attributes = attributes + assigneeChangeAttr;
  }
  attributes = attributes + "]";
  
  // we need to submit a card only if some changes have to be shown
  if (!equals(attributes, "[]")) {
    // Format JSON card description 
    var card = "{\"style\":\"application\", \"url\": \"" + invoke(ctx, ctx.issue, "getUrl", []) + "\", " + "\"format\":\"medium\", \"id\":\"" + id + "\", \"title\":\"" + title + "\", \"description\":{ \"value\": \"" + description + "\",  \"format\":\"html\"}," + "\"icon\":{\"url\":\"" + logo + "\"}, \"attributes\":" + attributes + "}";
    
    // Now we can format whole JSON request
    var json = "{\"color\":\"yellow\"," + "\"message\": \" " + description + "\", \"notify\": false, \"message_format\":\"html\"," + "\"card\":" + card + "}";
    
    // For each of rooms You want to notify:
    // integrations-> Build Your own integration -> Enter bot name (e.g youtrack) ->
    // add URL with token to the list below. Your code should looke like:
    // var URLs = "URL1,URL2,URL3".split(",", opts);
    
    // Example URLs
    var URLs = strOp("splitByWholeSeparator", "https://TEST_INSTANCE.hipchat.com/v2/room/room_number/notification?auth_token=TOKEN,https://TEST_INSTANCE.hipchat.com/v2/room/room_number/notification?auth_token=TOKEN", ",");
    
    // Send message to all of specified rooms
    for(var URL_iterator = URLs.iterator(); URL_iterator.hasNext();) {
      var URL = URL_iterator.next();
      invoke(ctx, ctx.issue, "addHttpHeader", ["Content-Type","application/json"]);
      var response = invoke(ctx, ctx.issue, "doHttpPost", [URL,json]);
      if (strOp("contains", response, "201") || strOp("contains", response, "204")) {
        log("debug", response, ctx);
      } else {
        log("error", response, ctx);
      }
    }
  }
  
}).addRequirements(requirements([{name: "Issue", fields: [{name: "summary", type: {name: "string", primitive: true}}, {name: "updated", type: {name: "instant", primitive: true}}, {name: "State", type: {name: "State"}}, {name: "Type", type: {name: "EnumField"}}, {name: "Priority", type: {name: "EnumField"}}, {name: "Assignee", type: {name: "User", fields: [{name: "fullName", type: {name: "string", primitive: true}}]}}]}]));