statelessrule("jetbrains-youtrack-doNotVoteForResolvedIssue", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "isResolved", []);
}, function(ctx) {
  assert(ctx, !safeCall(ctx.issue,"isChanged", ["votes"], false),localize("jetbrains-youtrack-doNotVoteForResolvedIssue.Voting_for_a_resolved_issue_is_not_allowed"));
}).addRequirements(requirements([{name: "Issue", fields: [{name: "votes", type: {name: "int", primitive: true}}]}]));