statelessrule("Clear Fix versions in reopened issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return !equals(safeCall(ctx.issue,"getOldValue", ["State"]), null) && safeCall(safeCall(ctx.issue,"getOldValue", ["State"]),"get", ["isResolved"], false) && !safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["isResolved"], false);
}, function(ctx) {
  safeCall(safeCall(ctx.issue,"get", ["Fix versions"]),"clear", []);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Fix versions", type: {name: "ProjectVersion", multiple: true}}, {name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}]}}]}]));