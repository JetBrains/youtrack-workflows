statemachine("Time Management", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User"}}, {name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User"}}]}}, {name: "Subsystem", type: {name: "OwnedField", fields: [{name: "owner", type: {name: "User"}}]}}, {name: "State", type: {name: "State", values: ["Submitted", "Open", "In Progress", "To be discussed", "Can't Reproduce", "Incomplete", "Verified", "Fixed", "Obsolete"]}}]}]));
from("Submitted").onEnter(function(ctx) {
  // Could be set to special subsystem!
});
from("Submitted").onExit(function(ctx) {
  require(ctx, ctx.issue, "Assignee", "Responsible support engineer is required!");
});
from("Submitted").after(joda.Period.hours(1)).transitTo("Open");
from("Submitted").on("reproducing").transitTo("In Progress");
from("Submitted").on("incomplete").transitTo("Incomplete");
from("Open").onEnter(function(ctx) {
  var user;
  
  if (!equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
    user = safeCall(ctx.issue,"get", ["Assignee"]);
  } else if (!equals(safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]);
  } else {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  invoke(ctx, user, "notify", ["Aknowledgement needed","Issue " + invoke(ctx, ctx.issue, "getId", []) + " is waiting for aknowledgement."]);
});
from("Open").on("incomplete").transitTo("Incomplete");
from("Open").on("reproducing").transitTo("In Progress");
from("In Progress").after(joda.Period.hours(4)).transitTo("To be discussed");
from("In Progress").on("approved").transitTo("Verified");
from("In Progress").on("incomplete").transitTo("Incomplete");
from("In Progress").on("can't reproduce").transitTo("Can't Reproduce");
from("To be discussed").after(joda.Period.days(1)).perform(function(ctx) {
  var user;
  
  if (!equals(safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]);
  } else {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  invoke(ctx, user, "notify", ["Issue is not reproduced in 1 day","Issue " + invoke(ctx, ctx.issue, "getId", []) + " is still waiting for reproduction steps."]);
  // Notify sales?
}).loop();
from("To be discussed").after(joda.Period.days(3)).perform(function(ctx) {
  var user;
  
  if (!equals(safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]);
  } else {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  invoke(ctx, user, "notify", ["Issue is not reproduced in 4 days","Issue " + invoke(ctx, ctx.issue, "getId", []) + " is not reproduced, it's better to visit customer on his site."]);
  // Notify sales?
}).loop();
from("To be discussed").on("approved").transitTo("Verified");
from("To be discussed").on("can't reproduce").transitTo("Can't Reproduce");
from("To be discussed").on("incomplete").transitTo("Incomplete");
from("Can't Reproduce").on("reopen").transitTo("In Progress");
from("Incomplete").on("reopen").transitTo("In Progress");
from("Verified").onEnter(function(ctx) {
  require(ctx, ctx.issue, "Assignee");
});
from("Verified").on("fixed").transitTo("Fixed");
from("Verified").on("obsolete").transitTo("Obsolete");
from("Fixed").on("reopen").transitTo("In Progress");
from("Obsolete").on("reopen").transitTo("In Progress");