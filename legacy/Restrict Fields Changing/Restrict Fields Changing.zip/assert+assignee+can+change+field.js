statelessrule("assert assignee can change field", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["Priority"], false) || safeCall(ctx.issue,"isChanged", ["Fix versions"], false) || safeCall(ctx.issue,"isChanged", ["Fixed in build"], false);
}, function(ctx) {
  assert(ctx, equals(ctx.loggedInUser, safeCall(ctx.issue,"get", ["Assignee"])),"Only an Issue Assignee can set with field");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User"}}, {name: "Fixed in build", type: {name: "Build"}}, {name: "Fix versions", type: {name: "ProjectVersion", multiple: true}}, {name: "Priority", type: {name: "EnumField"}}]}]));