statelessrule("Set 'Never' fixed in build for 'Won't fix' state", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Won't fix")], false);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["Fixed in build", find("Never")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Fixed in build", type: {name: "Build", values: ["Never"]}}, {name: "State", type: {name: "State", values: ["Won't fix"]}}]}]));