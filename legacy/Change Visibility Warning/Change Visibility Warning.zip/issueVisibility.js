statelessrule("issueVisibility", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["permittedGroup"], false);
}, function(ctx) {
  var msg = "Please make issue public and add protected attachments and comments to post non-public data";
  assert(ctx, invoke(ctx, ctx.loggedInUser, "isInGroup", ["jetbrains-team"]),msg);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "permittedGroup", type: {name: "UserGroup"}}]}]));