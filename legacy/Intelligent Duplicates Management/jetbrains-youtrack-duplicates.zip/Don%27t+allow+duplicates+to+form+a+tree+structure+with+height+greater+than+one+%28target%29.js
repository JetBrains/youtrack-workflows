statelessrule("Don't allow duplicates to form a tree structure with height greater than one (target)", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["is duplicated by"]),"isNotEmpty", [], false);
}, function(ctx) {
  log("info", "Processing duplicate-target issue " + invoke(ctx, ctx.issue, "getId", []), ctx);
  var target = safeCall(safeCall(ctx.issue,"get", ["duplicates"]),"first", []);
  if (!equals(target, null)) {
    // ban several duplicates for one issue
    safeCall(safeCall(ctx.issue,"get", ["duplicates"]),"clear", []);
    safeCall(safeCall(ctx.issue,"get", ["duplicates"]),"add", [target]);
    for(var incoming_iterator = safeCall(ctx.issue,"get", ["is duplicated by"]).iterator(); incoming_iterator.hasNext();) {
      var incoming = incoming_iterator.next();
      safeCall(safeCall(incoming,"get", ["duplicates"]),"remove", [ctx.issue]);
      if (equals(incoming, target)) {
        log("info", "Target cycle resolved for issue " + invoke(ctx, target, "getId", []), ctx);
      } else {
        safeCall(safeCall(incoming,"get", ["duplicates"]),"add", [target]);
      }
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true, methods: [{name: "getId", returnType: {name: "string"}}]}}]}}]}]));