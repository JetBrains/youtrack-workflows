statelessrule("When issue becomes duplicate it must have duplicate link", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Duplicate")], false);
}, function(ctx) {
  require(ctx, ctx.issue, "duplicates", localize("When_issue_becomes_duplicate_it_must_have_duplicate_link.Add_link_to_duplicate_issue"));
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}, {name: "State", type: {name: "State", values: ["Duplicate"]}}]}]));