statelessrule("When is duplicated link added set try to raise priority", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["is duplicated by"]),"isNotEmpty", [], false);
}, function(ctx) {
  if (!equals(safeCall(ctx.issue,"get", ["Priority"]), null)) {
    for(var source_iterator = safeCall(ctx.issue,"added", ["is duplicated by"]).iterator(); source_iterator.hasNext();) {
      var source = source_iterator.next();
      if (!equals(safeCall(ctx.issue,"get", ["project"]), safeCall(source,"get", ["project"])) && !equals(safeCall(valuesFor(ctx, safeCall(ctx.issue,"get", ["project"]), "Priority"),"first", []), safeCall(valuesFor(ctx, safeCall(source,"get", ["project"]), "Priority"),"first", []))) {
        continue;
      }
      
      var priorityOrdinal = safeCall(safeCall(ctx.issue,"get", ["Priority"]),"get", ["ordinal"], 0);
      var sourcePriority = safeCall(source,"get", ["Priority"]);
      if (!equals(sourcePriority, null)) {
        var sourcePriorityOrdinal = safeCall(sourcePriority,"get", ["ordinal"], 0);
        if (priorityOrdinal > sourcePriorityOrdinal) {
          priorityOrdinal = sourcePriorityOrdinal;
          safeCall(ctx.issue,"set", ["Priority", sourcePriority], null);
        }
      }
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "project", type: {name: "Project"}}, {name: "Priority", type: {name: "EnumField", fields: [{name: "ordinal", type: {name: "int", primitive: true}}]}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}]}]));