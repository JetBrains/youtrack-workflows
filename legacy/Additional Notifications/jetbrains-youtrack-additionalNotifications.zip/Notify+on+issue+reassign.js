statelessrule("Notify on issue reassign", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "isReported", []) && safeCall(ctx.issue,"isChanged", ["Assignee"], false) && !equals(ctx.loggedInUser, safeCall(ctx.issue,"getOldValue", ["Assignee"]));
}, function(ctx) {
  var oldAssignee = safeCall(ctx.issue,"getOldValue", ["Assignee"]);
  var newAssignee = "";
  if (equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
    newAssignee = localize("Notify_on_issue_reassign.nobody");
  } else {
    newAssignee = safeCall(safeCall(ctx.issue,"get", ["Assignee"]),"get", ["fullName"], null) + " (" + safeCall(safeCall(ctx.issue,"get", ["Assignee"]),"get", ["login"], null) + ")";
  }
  if (!equals(oldAssignee, null)) {
    invoke(ctx, oldAssignee, "notify", [localize("Notify_on_issue_reassign._YouTrack_Reassigned_Issue_{0}_{1}", invoke(ctx, ctx.issue, "getId", []), safeCall(ctx.issue,"get", ["summary"], null)),localize("Notify_on_issue_reassign.Issue_<a_href_{0}_>{1}</a>_was_reassigned_from_you_to_{2}", invoke(ctx, ctx.issue, "getUrl", []), invoke(ctx, ctx.issue, "getId", []), newAssignee)]);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Assignee", type: {name: "User", fields: [{name: "login", type: {name: "string", primitive: true}}, {name: "fullName", type: {name: "string", primitive: true}}], methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}, {name: "summary", type: {name: "string", primitive: true}}]}]));