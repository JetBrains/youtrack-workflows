statelessrule("Comment when won't fix", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Won't fix")], false);
}, function(ctx) {
  assert(ctx, safeCall(safeCall(ctx.issue,"added", ["comments"]),"isNotEmpty", [], false),"Please comment!");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "comments", type: {name: "IssueComment", multiple: true}}, {name: "State", type: {name: "State", values: ["Won't fix"]}}]}]));