statelessrule("Assert Fix version is set for Fixed issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Fixed")], false);
}, function(ctx) {
  require(ctx, ctx.issue, "Fix versions", localize("Assert_Fix_version_is_set_for_Fixed_issues.Please_set_the_Fix_versions_field"));
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Fix versions", type: {name: "ProjectVersion", multiple: true}}, {name: "State", type: {name: "State", values: ["Fixed"]}}]}]));