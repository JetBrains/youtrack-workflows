statelessrule("Accumulate subtasks estimates", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["IntEstimation"], false);
}, function(ctx) {
  var parent = safeCall(safeCall(ctx.issue,"get", ["subtask of"]),"first", []);
  if (!equals(parent, null)) {
    var estimation = 0;
    for(var subtask_iterator = safeCall(parent,"get", ["parent for"]).iterator(); subtask_iterator.hasNext();) {
      var subtask = subtask_iterator.next();
      estimation = estimation + safeCall(subtask,"get", ["IntEstimation"], 0);
    }
    safeCall(parent,"set", ["IntEstimation", estimation], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Subtask", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "parent for", type: {name: "Issue", multiple: true}}, {name: "subtask of", type: {name: "Issue", multiple: true}}]}}, {name: "IntEstimation", type: {name: "int", primitive: true}}]}]));