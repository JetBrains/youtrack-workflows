statelessrule("No Comments for Verified Issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["State"]), find("Verified")) && !safeCall(ctx.issue,"becomes", ["State", find("Verified")], false);
}, function(ctx) {
  assert(ctx, safeCall(safeCall(ctx.issue,"added", ["comments"]),"isEmpty", [], false),localize("No_Comments_for_Verified_Issues.Commenting_for_fixed_and_verified_issues_is_disabled"));
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Verified"]}}, {name: "comments", type: {name: "IssueComment", multiple: true}}]}]));