statemachine("State lifecycle with verification by reporter", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "Fixed in build", type: {name: "Build"}}, {name: "Assignee", type: {name: "User"}}, {name: "reporter", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}, {name: "State", type: {name: "State", values: ["Submitted", "Open", "Fixed", "Pending verification", "Verified"]}}]}]));
from("Submitted").on("Open ").transitTo("Open");
from("Open").on(" Fix ").transitTo("Fixed");
from("Fixed").onEnter(function(ctx) {
  require(ctx, ctx.issue, "Fixed in build", localize("State_lifecycle_with_verification_by_reporter.Please_set_Fixed_in_build_value"));
});
from("Fixed").on("Send for verification ").transitTo("Pending verification");
from("Pending verification").onEnter(function(ctx) {
  safeCall(ctx.issue,"set", ["Assignee", safeCall(ctx.issue,"get", ["reporter"])], null);
  invoke(ctx, safeCall(ctx.issue,"get", ["reporter"]), "notify", [localize("State_lifecycle_with_verification_by_reporter.Please_approve_fix_for_the_issue_{0}", invoke(ctx, ctx.issue, "getId", [])),localize("State_lifecycle_with_verification_by_reporter.You_have_reported_issue", invoke(ctx, ctx.issue, "getId", []))]);
});
from("Pending verification").on("Approve ").transitTo("Verified");
from("Pending verification").on("Re-open ").transitTo("Open");
from("Verified").on("Re-open").transitTo("Open");