statemachine("State lifecycle with verification by reporter", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "Fixed in build", type: {name: "Build"}}, {name: "Assignee", type: {name: "User"}}, {name: "reporter", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}, {name: "State", type: {name: "State", values: ["Submitted", "Open", "Fixed", "Pending verification", "Verified"]}}]}]));
from("Submitted").on("Open ").transitTo("Open");
from("Open").on(" Fix ").transitTo("Fixed");
from("Fixed").onEnter(function(ctx) {
  require(ctx, ctx.issue, "Fixed in build", "Please set 'Fixed in build' value.");
});
from("Fixed").on("Send for verification ").transitTo("Pending verification");
from("Pending verification").onEnter(function(ctx) {
  safeCall(ctx.issue,"set", ["Assignee", safeCall(ctx.issue,"get", ["reporter"])], null);
  invoke(ctx, safeCall(ctx.issue,"get", ["reporter"]), "notify", ["Please approve fix for the issue" + invoke(ctx, ctx.issue, "getId", []),"You have reported issue" + invoke(ctx, ctx.issue, "getId", []) + "Please verify the applied fix for the issue and set the appropriate state."]);
});
from("Pending verification").on("Approve ").transitTo("Verified");
from("Pending verification").on("Re-open ").transitTo("Open");
from("Verified").on("Re-open").transitTo("Open");