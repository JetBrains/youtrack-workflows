statelessrule("Send specific notification to reporter to approve fix", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Pending verification")], false);
}, function(ctx) {
  invoke(ctx, safeCall(ctx.issue,"get", ["reporter"]), "notify", ["Please approve fix for the issue" + invoke(ctx, ctx.issue, "getId", []),"You have reported issue" + invoke(ctx, ctx.issue, "getId", []) + "Please verify the applied fix for the issue and set the appropriate state."]);
  safeCall(ctx.issue,"set", ["Assignee", safeCall(ctx.issue,"get", ["reporter"])], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "reporter", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}, {name: "Assignee", type: {name: "User"}}, {name: "State", type: {name: "State", values: ["Pending verification"]}}]}]));