statelessrule("Set subsystem owner as assignee for unassigned issues", model.Event.BEFORE_FLUSH, function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["Assignee"]), null) && (((safeCall(ctx.issue,"isChanged", ["Subsystem"], false) || safeCall(ctx.issue,"isChanged", ["project"], false)) && invoke(ctx, ctx.issue, "isReported", [])) || invoke(ctx, ctx.issue, "becomesReported", []));
}, function(ctx) {
  if (!equals(safeCall(ctx.issue,"get", ["Subsystem"]), null)) {
    safeCall(ctx.issue,"set", ["Assignee", safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"])], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Subsystem", type: {name: "OwnedField", fields: [{name: "owner", type: {name: "User"}}]}}, {name: "Assignee", type: {name: "User"}}, {name: "project", type: {name: "Project"}}]}]));