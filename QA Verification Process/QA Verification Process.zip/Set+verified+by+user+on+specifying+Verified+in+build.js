statelessrule("Set verified by user on specifying Verified in build", model.Event.BEFORE_FLUSH, function(ctx) {
  return !equals(safeCall(ctx.issue,"get", ["Verified in build"]), null) && safeCall(ctx.issue,"isChanged", ["Verified in build"], false);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["Verified by", ctx.loggedInUser], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Verified by", type: {name: "User"}}, {name: "Verified in build", type: {name: "Build"}}]}]));