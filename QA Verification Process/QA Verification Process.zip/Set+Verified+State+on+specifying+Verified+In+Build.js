statelessrule("Set Verified State on specifying Verified In Build", model.Event.BEFORE_FLUSH, function(ctx) {
  return !equals(safeCall(ctx.issue,"get", ["Verified in build"]), null) && !equals(safeCall(ctx.issue,"get", ["State"]), find("Verified"));
}, function(ctx) {
  safeCall(ctx.issue,"set", ["State", find("Verified")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Verified"]}}, {name: "Verified in build", type: {name: "Build"}}]}]));