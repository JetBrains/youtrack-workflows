statelessrule("Require comment on w/o verification", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("W/O verification")], false);
}, function(ctx) {
  assert(ctx, safeCall(safeCall(ctx.issue,"added", ["comments"]),"isNotEmpty", [], false),"Please add comment in Command Window");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "comments", type: {name: "IssueComment", multiple: true}}, {name: "State", type: {name: "State", values: ["W/O verification"]}}]}]));