statemachine("States", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "Verified by", type: {name: "User"}}, {name: "Verified in build", type: {name: "Build"}}, {name: "State", type: {name: "State", values: ["Submitted", "Open", "W/O verification", "Verified"]}}]}]));
from("Submitted");
from("Open");
from("W/O verification").onEnter(function(ctx) {
  safeCall(ctx.issue,"set", ["Verified by", ctx.loggedInUser], null);
});
from("W/O verification").on("reopen").transitTo("Open");
from("Verified").on("reopen").transitTo("Open");
from("Verified").onEnter(function(ctx) {
  require(ctx, ctx.issue, "Verified in build", "Specify verified in build");
  safeCall(ctx.issue,"set", ["Verified by", ctx.loggedInUser], null);
});
from("Verified").onExit(function(ctx) {
  safeCall(ctx.issue,"set", ["Verified in build", null], null);
});