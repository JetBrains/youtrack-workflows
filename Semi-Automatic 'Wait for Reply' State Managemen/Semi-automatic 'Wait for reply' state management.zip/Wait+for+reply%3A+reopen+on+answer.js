statelessrule("Wait for reply: reopen on answer", model.Event.BEFORE_FLUSH, function(ctx) {
  return equals(safeCall(ctx.issue,"get", ["State"]), find("Wait for Reply")) && !equals(safeCall(ctx.issue,"added", ["comments"]), null) && safeCall(safeCall(ctx.issue,"added", ["comments"]),"isNotEmpty", [], false) && !equals(safeCall(safeCall(ctx.issue,"added", ["comments"]),"last", []), null) && !invoke(ctx, safeCall(safeCall(safeCall(ctx.issue,"added", ["comments"]),"last", []),"get", ["author"]), "isInGroup", ["youtrack-developers"]);
}, function(ctx) {
  
  safeCall(ctx.issue,"set", ["State", find("Open")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Open", "Wait for Reply"]}}, {name: "comments", type: {name: "IssueComment", multiple: true, fields: [{name: "author", type: {name: "User", methods: [{name: "isInGroup", returnType: {name: "boolean"}, paramTypes: [{name: "string"}]}]}}]}}]}]));