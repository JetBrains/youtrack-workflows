statemachine("States machine", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Submitted", "Open", "Wait for Reply"]}}]}]));
from("Submitted").on("wait").transitTo("Wait for Reply");
from("Open").on("wait").transitTo("Wait for Reply");
from("Wait for Reply").on("reopen").transitTo("Open");