statelessrule("Different duplicates issues visibility", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(safeCall(ctx.issue,"added", ["duplicates"]),"isNotEmpty", [], false);
}, function(ctx) {
  for(var duplicate_iterator = safeCall(ctx.issue,"added", ["duplicates"]).iterator(); duplicate_iterator.hasNext();) {
    var duplicate = duplicate_iterator.next();
    assert(ctx, equals(safeCall(ctx.issue,"get", ["permittedGroup"]), safeCall(duplicate,"get", ["permittedGroup"])),"Try to duplicate issue with different visibility");
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "permittedGroup", type: {name: "UserGroup"}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}]}]));