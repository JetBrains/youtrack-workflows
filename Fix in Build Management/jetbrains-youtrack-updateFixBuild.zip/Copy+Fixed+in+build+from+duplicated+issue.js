statelessrule("Copy Fixed in build from duplicated issue", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"becomes", ["State", find("Duplicate")], false) && safeCall(safeCall(ctx.issue,"get", ["duplicates"]),"isNotEmpty", [], false);
}, function(ctx) {
  for(var duplicatedIssue_iterator = safeCall(ctx.issue,"get", ["duplicates"]).iterator(); duplicatedIssue_iterator.hasNext();) {
    var duplicatedIssue = duplicatedIssue_iterator.next();
    if (equals(safeCall(duplicatedIssue,"get", ["project"]), safeCall(ctx.issue,"get", ["project"])) && !equals(safeCall(duplicatedIssue,"get", ["Fixed in build"]), null)) {
      safeCall(ctx.issue,"set", ["Fixed in build", safeCall(duplicatedIssue,"get", ["Fixed in build"])], null);
      break;
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Fixed in build", type: {name: "Build"}}, {name: "project", type: {name: "Project"}}, {name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}, {name: "State", type: {name: "State", values: ["Duplicate"]}}]}]));