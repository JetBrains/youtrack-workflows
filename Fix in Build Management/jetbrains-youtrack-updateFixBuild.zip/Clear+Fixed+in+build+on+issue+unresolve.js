statelessrule("Clear Fixed in build on issue unresolve", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "isReported", []) && !(safeCall(safeCall(ctx.issue,"get", ["State"]),"get", ["isResolved"], false)) && !equals(safeCall(ctx.issue,"getOldValue", ["State"]), null) && safeCall(safeCall(ctx.issue,"getOldValue", ["State"]),"get", ["isResolved"], false);
}, function(ctx) {
  if (!equals(safeCall(ctx.issue,"get", ["Fixed in build"]), null)) {
    safeCall(ctx.issue,"set", ["Fixed in build", null], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Fixed in build", type: {name: "Build"}}, {name: "State", type: {name: "State", fields: [{name: "isResolved", type: {name: "boolean", primitive: true}}]}}]}]));