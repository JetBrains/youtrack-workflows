statelessrule("Copy Fixed in build to duplicate issues when it is set", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["Fixed in build"], false) && !equals(safeCall(ctx.issue,"get", ["Fixed in build"]), null);
}, function(ctx) {
  var duplicatedBy = safeCall(ctx.issue,"get", ["is duplicated by"]);
  for(var duplicate_iterator = duplicatedBy.iterator(); duplicate_iterator.hasNext();) {
    var duplicate = duplicate_iterator.next();
    if (equals(safeCall(duplicate,"get", ["project"]), safeCall(ctx.issue,"get", ["project"]))) {
      safeCall(duplicate,"set", ["Fixed in build", safeCall(ctx.issue,"get", ["Fixed in build"])], null);
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Duplicate", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "is duplicated by", type: {name: "Issue", multiple: true}}, {name: "duplicates", type: {name: "Issue", multiple: true}}]}}, {name: "Fixed in build", type: {name: "Build"}}, {name: "project", type: {name: "Project"}}]}]));