statemachine("Time Management", "State").addRequirements(requirements([{name: "Issue", fields: [{name: "Subsystem", type: {name: "OwnedField", fields: [{name: "owner", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}], values: ["Support"]}}, {name: "Assignee", type: {name: "User", methods: [{name: "notify", returnType: {name: "void"}, paramTypes: [{name: "string"}, {name: "string"}]}]}}, {name: "project", type: {name: "Project", fields: [{name: "leader", type: {name: "User"}}]}}, {name: "State", type: {name: "State", values: ["Submitted", "Overdue", "Open", "Wait for reproduce", "Can't Reproduce", "Incomplete", "Approved", "Fixed", "Obsolete", "Verified"]}}]}]));
from("Submitted").onEnter(function(ctx) {
  safeCall(ctx.issue,"set", ["Subsystem", find("Support")], null);
});
from("Submitted").onExit(function(ctx) {
  require(ctx, ctx.issue, "Assignee", "Responsible support engineer is required!");
});
from("Submitted").after(joda.Period.hours(1)).transitTo("Overdue");
from("Submitted").on("reproducing").transitTo("Open");
from("Submitted").on("incomplete").transitTo("Incomplete");
from("Overdue").onEnter(function(ctx) {
  var user;
  
  if (!equals(safeCall(ctx.issue,"get", ["Assignee"]), null)) {
    user = safeCall(ctx.issue,"get", ["Assignee"]);
  } else if (!equals(safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]);
  } else {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  invoke(ctx, user, "notify", ["Aknowledgement needed","Issue " + invoke(ctx, ctx.issue, "getId", []) + " is waiting for aknowledgement."]);
});
from("Overdue").on("incomplete").transitTo("Incomplete");
from("Overdue").on("reproducing").transitTo("Open");
from("Open").after(joda.Period.hours(4)).transitTo("Wait for reproduce");
from("Open").on("approved").transitTo("Approved");
from("Open").on("incomplete").transitTo("Incomplete");
from("Open").on("can't reproduce").transitTo("Can't Reproduce");
from("Wait for reproduce").after(joda.Period.days(1)).perform(function(ctx) {
  var user;
  
  if (!equals(safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]);
  } else {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  invoke(ctx, user, "notify", ["Issue is not reproduced in 1 day","Issue " + invoke(ctx, ctx.issue, "getId", []) + " is still waiting for reproduction steps."]);
  // Notify sales?
}).loop();
from("Wait for reproduce").after(joda.Period.days(3)).perform(function(ctx) {
  var user;
  
  if (!equals(safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]), null)) {
    user = safeCall(safeCall(ctx.issue,"get", ["Subsystem"]),"get", ["owner"]);
  } else {
    user = safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["leader"]);
  }
  invoke(ctx, user, "notify", ["Issue is not reproduced in 4 days","Issue " + invoke(ctx, ctx.issue, "getId", []) + " is not reproduced, it's better to visit customer on his site."]);
  // Notify sales?
}).loop();
from("Wait for reproduce").on("approved").transitTo("Approved");
from("Wait for reproduce").on("can't reproduce").transitTo("Can't Reproduce");
from("Wait for reproduce").on("incomplete").transitTo("Incomplete");
from("Can't Reproduce").on("reopen").transitTo("Open");
from("Incomplete").on("reopen").transitTo("Open");
from("Approved").onEnter(function(ctx) {
  require(ctx, ctx.issue, "Assignee");
});
from("Approved").on("fixed").transitTo("Fixed");
from("Approved").on("obsolete").transitTo("Obsolete");
from("Fixed").on("verify").transitTo("Verified");
from("Fixed").on("reopen").transitTo("Open");
from("Obsolete").on("reopen").transitTo("Open");
from("Verified").on("reopen").transitTo("Open");