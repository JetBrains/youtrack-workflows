statelessrule("Don't change reason manually", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["Pomodoro interruption"], false);
}, function(ctx) {
  var causes = equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Boss interrupted")) || equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Facebook chat")) || equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Phone call")) || equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Urgent email"));
  
  assert(ctx, safeCall(ctx.issue,"isChanged", ["Pomodoro state"], false),"Cannot change the interruption cause without changing the timer state.");
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Pomodoro interruption", type: {name: "EnumField", values: ["Boss interrupted", "Facebook chat", "Phone call", "Urgent email"]}}, {name: "Pomodoro state", type: {name: "State"}}]}]));