onschedulestatelessrule("Pomodoro countdown", model.Event.CRON, "0 * * * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.and(w.neq("Pomodoro countdown",null),w.neq("Pomodoro countdown",0));
}, function(ctx) {
  if (equals(safeCall(ctx.issue,"get", ["Pomodoro state"]), find("Timer’s running")) || equals(safeCall(ctx.issue,"get", ["Pomodoro state"]), find("On a break"))) {
    safeCall(ctx.issue,"set", ["Pomodoro countdown", safeCall(ctx.issue,"get", ["Pomodoro countdown"], 0) - 1], null);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Pomodoro countdown", type: {name: "int", primitive: true}}, {name: "Pomodoro state", type: {name: "State", values: ["On a break", "Timer’s running"]}}]}]));