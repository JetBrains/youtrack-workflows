statelessrule("Don't change reason manually", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", [""], false);
}, function(ctx) {
  // The Pomodoro technique is a time management method created by Francesco Cirillo in the 1980s. For details visit http://www.pomodorotechnique.com/
  var causes = equals(safeCall(ctx.issue,"get", [""]), find("Boss interrupted")) || equals(safeCall(ctx.issue,"get", [""]), find("Facebook chat")) || equals(safeCall(ctx.issue,"get", [""]), find("Phone call")) || equals(safeCall(ctx.issue,"get", [""]), find("Urgent email"));
  
  assert(ctx, safeCall(ctx.issue,"isChanged", [""], false),localize("Don_t_change_reason_manually.Cannot_change_the_interruption_cause_without_changing_the_timer_state"));
}).addRequirements(requirements([{name: "Issue"}]));