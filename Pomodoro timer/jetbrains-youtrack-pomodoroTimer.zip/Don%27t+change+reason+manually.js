statelessrule("Don't change reason manually", model.Event.BEFORE_FLUSH, function(ctx) {
  return safeCall(ctx.issue,"isChanged", ["Pomodoro interruption"], false);
}, function(ctx) {
  // The Pomodoro technique is a time management method created by Francesco Cirillo in the 1980s. For details visit http://www.pomodorotechnique.com/
  var causes = equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Boss interrupted")) || equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Facebook chat")) || equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Phone call")) || equals(safeCall(ctx.issue,"get", ["Pomodoro interruption"]), find("Urgent email"));
  
  assert(ctx, safeCall(ctx.issue,"isChanged", ["Pomodoro state"], false),localize("Don_t_change_reason_manually.Cannot_change_the_interruption_cause_without_changing_the_timer_state"));
}).addRequirements(requirements([{name: "Issue", fields: [{name: "Pomodoro interruption", type: {name: "EnumField", values: ["Boss interrupted", "Facebook chat", "Phone call", "Urgent email"]}}, {name: "Pomodoro state", type: {name: "State"}}]}]));