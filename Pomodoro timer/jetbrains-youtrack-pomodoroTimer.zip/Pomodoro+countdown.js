onschedulestatelessrule("Pomodoro countdown", model.Event.CRON, "0 * * * * ?", function(p) {
  var w = new model.WhereBuilder(p);
  return w.and(w.neq("",null),w.neq("",0));
}, function(ctx) {
  // The Pomodoro technique is a time management method created by Francesco Cirillo in the 1980s. For details visit http://www.pomodorotechnique.com/
  if (equals(safeCall(ctx.issue,"get", [""]), find("Timer’s running")) || equals(safeCall(ctx.issue,"get", [""]), find("On a break"))) {
    safeCall(ctx.issue,"set", ["", safeCall(ctx.issue,"get", [""]) - 1], null);
  }
}).addRequirements(requirements([{name: "Issue"}]));