statemachine("Pomodoro states", "Pomodoro state").addRequirements(requirements([{name: "Issue", fields: [{name: "Pomodoro interruption", type: {name: "EnumField", fields: [{name: "name", type: {name: "string", primitive: true}}]}}, {name: "Pomodoro countdown", type: {name: "int", primitive: true}}, {name: "Pomodoro state", type: {name: "State", values: ["Not set", "Timer’s running", "Timer finished", "On a break"]}}]}]));
from("Not set").on("start").perform(function(ctx) {
  // The Pomodoro technique is a time management method created by Francesco Cirillo in the 1980s. For details visit http://www.pomodorotechnique.com/
}).transitTo("Timer’s running");
from("Timer’s running").onEnter(function(ctx) {
  safeCall(ctx.issue,"set", ["Pomodoro interruption", null], null);
  message(ctx,localize("Pomodoro_states.25_minutes_pomodoro_is_started"));
  safeCall(ctx.issue,"set", ["Pomodoro countdown", 25], null);
});
from("Timer’s running").on("interrupt").perform(function(ctx) {
  require(ctx, ctx.issue, "Pomodoro interruption", localize("Pomodoro_states.Please_specify_the_interruption_cause"));
  invoke(ctx, ctx.issue, "applyCommand", ["add work Today " + (25 - safeCall(ctx.issue,"get", ["Pomodoro countdown"], 0)) + "m " + localize("Pomodoro_states._Pomodoro_was_interrupted_The_cause") + safeCall(safeCall(ctx.issue,"get", ["Pomodoro interruption"]),"get", ["name"], null) + "'."]);
  safeCall(ctx.issue,"set", ["Pomodoro countdown", null], null);
}).transitTo("Not set");
from("Timer’s running").after(joda.Period.minutes(25)).transitTo("Timer finished");
from("Timer finished").on("take a break").perform(function(ctx) {
  message(ctx,localize("Pomodoro_states._5_minutes_break"));
  invoke(ctx, ctx.issue, "applyCommand", ["add work Today 25m" + " +1 pomodoro."]);
  safeCall(ctx.issue,"set", ["Pomodoro countdown", 5], null);
}).transitTo("On a break");
from("Timer finished").on("discard").perform(function(ctx) {
  require(ctx, ctx.issue, "Pomodoro interruption", localize("Pomodoro_states._Please_specify_the_interruption_cause"));
  invoke(ctx, ctx.issue, "applyCommand", ["add work Today " + "25m " + localize("Pomodoro_states._Pomodoro_was_discarded_The_cause") + safeCall(safeCall(ctx.issue,"get", ["Pomodoro interruption"]),"get", ["name"], null) + "'."]);
  safeCall(ctx.issue,"set", ["Pomodoro countdown", null], null);
}).transitTo("Not set");
from("On a break").on("start").perform(function(ctx) {
  invoke(ctx, ctx.issue, "applyCommand", ["add work Today " + (5 - safeCall(ctx.issue,"get", ["Pomodoro countdown"], 0)) + "m " + localize("Pomodoro_states._1_short_break")]);
}).transitTo("Timer’s running");
from("On a break").after(joda.Period.minutes(5)).perform(function(ctx) {
  invoke(ctx, ctx.issue, "applyCommand", ["add work Today 5m " + localize("Pomodoro_states._1_break")]);
}).transitTo("Not set");