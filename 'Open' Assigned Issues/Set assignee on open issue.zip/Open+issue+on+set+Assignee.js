statelessrule("Open issue on set Assignee", model.Event.BEFORE_FLUSH, function(ctx) {
  return !equals(safeCall(ctx.issue,"get", ["Assignee"]), null) && safeCall(ctx.issue,"isChanged", ["Assignee"], false) && equals(safeCall(ctx.issue,"getOldValue", ["Assignee"]), null);
}, function(ctx) {
  safeCall(ctx.issue,"set", ["State", find("Open")], null);
}).addRequirements(requirements([{name: "Issue", fields: [{name: "State", type: {name: "State", values: ["Open"]}}, {name: "Assignee", type: {name: "User"}}]}]));